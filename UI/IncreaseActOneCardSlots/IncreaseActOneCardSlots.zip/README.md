﻿# Increasing Act 1 Slots

- [Full, non-resized image here](https://i.imgur.com/Liyo0R6.png)

## Objects positions/size to handle new layout (Act 1)

### Table related items

- Bell and Scales: Farther left.
- Candle Holder: Moved farther right.
- Card Draw Piles: Moved farther right.
- Consumable items: Moved to the right to avoid overlapping far-right slot.
- Sacrifice Tokens: Moved farther right.
- Table RuleBook: Moved left and down.

### Boss related items

- Giant Moon: Scaled to now fit across 5 slots.
- Prospector: Tress on the left were moved farther outward so that the bell and scales could be seen easier.
- Trader/Trapper: Knives were moved outward to avoid clipping into the table.
